/**
 * 插件的管理
 */
export default {

}